#!/bin/sh
bash /work/script/run_eth_proxy.sh &&
bash /work/script/run_btc_proxy.sh &&
sudo -S  bash /work/script/run_ltc_proxy.sh &&
sudo -S  bash /work/script/run_tls_proxy.sh &&
sudo -S  bash /work/script/run_dash_proxy.sh &&


echo "-----------------------------------" &&
echo "               ALL is OK         "
