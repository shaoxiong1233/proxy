#!/bin/sh


sysctl -w net.ipv4.neigh.default.gc_thresh1=1024 &&
sysctl -w net.ipv4.neigh.default.gc_thresh2=2048 &&
sysctl -w net.ipv4.neigh.default.gc_thresh3=4096 &&
apt-get install -f -y &&
dpkg -i /work/script/sunloginclientshell-10.1.1.28779-amd64.deb &&
bash /work/init/second.sh

